/*     Foma: a finite-state toolkit and library.                             */
/*     Copyright © 2008-2009 Mans Hulden                                     */

/*     This file is part of foma.                                            */

/*     Foma is free software: you can redistribute it and/or modify          */
/*     it under the terms of the GNU General Public License version 2 as     */
/*     published by the Free Software Foundation. */

/*     Foma is distributed in the hope that it will be useful,               */
/*     but WITHOUT ANY WARRANTY; without even the implied warranty of        */
/*     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         */
/*     GNU General Public License for more details.                          */

/*     You should have received a copy of the GNU General Public License     */
/*     along with foma.  If not, see <http://www.gnu.org/licenses/>.         */

#include <stdlib.h>
#include "foma.h"

/* int dfa_sort_cmp2(const struct fsm_state *a, const struct fsm_state *b) { */
/*   return (a->state_no - b->state_no); */
/* } */

struct fsm *fsm_reverse(struct fsm *net) {
  struct fsm_state *fsm, *rev_fsm;
  int i,j, statecount = 0, arccount = 0, numstarts = 0;
  _Bool *finals, *starts;
  fsm = net->states;

  /* Check if we only have one state with no arcs */
  if ((fsm)->target == -1 && (fsm+1)->state_no == -1) {
    return(net);
  }

  /* Create final states array */
  for (i=0; (fsm+i)->state_no != -1; i++) {
    if ((fsm+i)->state_no > statecount) {
      statecount = (fsm+i)->state_no;
    }
    arccount++;
  }
  statecount++;

  finals = xxmalloc_atomic((sizeof(_Bool))*statecount);
  starts = xxmalloc_atomic((sizeof(_Bool))*statecount);

  for (i = 0; i<statecount; i++) {
    finals[i] = 0;
    starts[i] = 0;
  }

  /* push start states on stack */
  for (i=0; (fsm+i)->state_no != -1; i++) {
    if (((fsm+i)->start_state == 1)) {
      numstarts++;
      starts[(fsm+i)->state_no] = 1;
    }
    if (((fsm+i)->final_state == 1)) {
      finals[(fsm+i)->state_no] = 1;
    }
  }

  rev_fsm = xxmalloc(sizeof(struct fsm_state)*(arccount+numstarts+1));

  /* Reverse arcs */
  for (i=0, j=0 ; (fsm+i)->state_no != -1 ; i++) {
    if ((fsm+i)->target == -1) {
      continue;
    }
    if (finals[(fsm+i)->target] == 1) {
      (rev_fsm+j)->start_state = 1;
    } else {
      (rev_fsm+j)->start_state = 0;
    }
    if (starts[(fsm+i)->target] == 1) {
      (rev_fsm+j)->final_state = 1;
    } else {
      (rev_fsm+j)->final_state = 0;
    }
    (rev_fsm+j)->in = (fsm+i)->in;
    (rev_fsm+j)->out = (fsm+i)->out;
    (rev_fsm+j)->target = (fsm+i)->state_no;
    (rev_fsm+j)->state_no = (fsm+i)->target;
    j++;
  }
  
  /* Go through old start states */

  for (i=0; i<j; i++) {
    starts[(rev_fsm+i)->state_no] = 0;
  }
  for (i=0; i < statecount; i++) {
    if (starts[i] == 1) {
      (rev_fsm+j)->state_no = i;
      (rev_fsm+j)->in = -1;
      (rev_fsm+j)->out = -1;
      (rev_fsm+j)->target = -1;
      (rev_fsm+j)->final_state = 1;
      /* Wrong */
      (rev_fsm+j)->start_state = finals[(rev_fsm+j)->state_no];
      j++;
    }
  }    

  (rev_fsm+j)->state_no = -1;
  (rev_fsm+j)->in = -1;
  (rev_fsm+j)->out = -1;
  (rev_fsm+j)->target = -1;
  (rev_fsm+j)->final_state = -1;
  (rev_fsm+j)->start_state = -1;

  /* xxfree(fsm); */
  qsort(rev_fsm, find_arccount(rev_fsm), sizeof(struct fsm_state), sort_cmp);
  net->states = rev_fsm;

  xxfree(starts);
  xxfree(finals);
  /* xxfree(fsm); */
  fsm_update_flags(net, UNK, UNK, UNK, UNK, UNK, UNK);
  return(net);
}
